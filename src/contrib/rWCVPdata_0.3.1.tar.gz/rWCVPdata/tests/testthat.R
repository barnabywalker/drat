library(testthat)
library(rWCVPdata)

test_check("rWCVPdata")
